<%
' ============================================
' 网站配置文件
' ============================================

' 网站基本信息
Const SITE_NAME = "香氛定制"
Const SITE_URL = "http://localhost"
Const SITE_EMAIL = "contact@perfumeshop.com"
Const SITE_PHONE = "400-888-8888"

' 系统版本
Const SYS_VERSION = "V13.3"
Const SYS_VERSION_NAME = "香氛定制系统V13.3 - AMP+骨架屏+CDN加速"

' 数据库连接配置已迁移至 connection.asp (SQL Server)
' Const DB_CONNECTION_STRING 已废弃，连接字符串在 connection.asp 中定义

' 分页设置
Const PAGE_SIZE = 12

' 运费设置
Const FREE_SHIPPING_AMOUNT = 299
Const SHIPPING_FEE = 15

' 图片路径
Const IMAGE_PATH = "/images/"
Const DEFAULT_PRODUCT_IMAGE = "/images/default-product.svg"
Const DEFAULT_AVATAR = "/images/default-avatar.svg"

' 图片上传路径
Const UPLOAD_PATH_PRODUCTS = "/images/products/"
Const UPLOAD_PATH_NOTES = "/images/notes/"
Const UPLOAD_PATH_BOTTLES = "/images/bottles/"
Const UPLOAD_PATH_AVATARS = "/images/avatars/"
Const UPLOAD_PATH_DEFAULT = "/images/uploads/"

' Session超时时间（分钟）
Session.Timeout = 60

' === V10 安全响应头 ===
Response.AddHeader "X-Content-Type-Options", "nosniff"
Response.AddHeader "X-Frame-Options", "SAMEORIGIN"
Response.AddHeader "X-XSS-Protection", "1; mode=block"
Response.AddHeader "Referrer-Policy", "strict-origin-when-cross-origin"
' V13.3: CDN启用后需添加CDN域名到img-src（如 https://cdn.perfumeshop.com）
Response.AddHeader "Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com https://code.jquery.com https://cdn.ampproject.org; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; img-src 'self' data: https:; font-src 'self' https://cdnjs.cloudflare.com; connect-src 'self'; frame-ancestors 'self'; base-uri 'self'; form-action 'self'"
Response.AddHeader "Strict-Transport-Security", "max-age=31536000"
Response.AddHeader "Permissions-Policy", "camera=(), microphone=(), geolocation=()"

' ============================================
' V10.3: Application级缓存层
' ============================================
Const CACHE_DEFAULT_TTL = 300  ' 默认缓存5分钟

' 从缓存获取值
Function CacheGet(key)
    Dim cacheKey : cacheKey = "CACHE_" & key
    Dim cacheEntry, cacheTime, cacheTTL
    cacheEntry = Application(cacheKey)
    If IsEmpty(cacheEntry) Or cacheEntry = "" Then
        CacheGet = Empty
        Exit Function
    End If
    ' 格式: timestamp|ttl|value
    Dim parts : parts = Split(cacheEntry, Chr(1))
    If UBound(parts) < 2 Then
        CacheGet = Empty
        Exit Function
    End If
    cacheTime = CDbl(parts(0))
    cacheTTL = CInt(parts(1))
    If DateDiff("s", CDate(cacheTime), Now()) > cacheTTL Then
        CacheGet = Empty  ' 已过期
    Else
        CacheGet = parts(2)
    End If
End Function

' 设置缓存值
Sub CacheSet(key, value, ttlSeconds)
    If IsNull(ttlSeconds) Or ttlSeconds = "" Or ttlSeconds <= 0 Then ttlSeconds = CACHE_DEFAULT_TTL
    Dim cacheKey : cacheKey = "CACHE_" & key
    Dim cacheEntry : cacheEntry = CDbl(Timer()) & Chr(1) & ttlSeconds & Chr(1) & value
    Application.Lock
    Application(cacheKey) = cacheEntry
    Application.Unlock
End Sub

' 清除指定缓存
Sub CacheClear(key)
    Application.Lock
    Application("CACHE_" & key) = ""
    Application.Unlock
End Sub

' 预加载常用缓存（SiteSettings, Volumes）
' 在各页面首次需要时自动调用
Function GetCachedSiteSettings(conn)
    Dim cached : cached = CacheGet("SiteSettings_All")
    If Not IsEmpty(cached) Then
        GetCachedSiteSettings = cached
        Exit Function
    End If
    Dim rs, settings
    On Error Resume Next
    Set rs = conn.Execute("SELECT SettingKey, SettingValue FROM SiteSettings")
    If Err.Number = 0 And Not rs Is Nothing Then
        settings = ""
        Do While Not rs.EOF
            settings = settings & rs("SettingKey") & "=" & rs("SettingValue") & Chr(2)
            rs.MoveNext
        Loop
        rs.Close
        CacheSet "SiteSettings_All", settings, 600
    End If
    Err.Clear : Set rs = Nothing
    On Error GoTo 0
    GetCachedSiteSettings = settings
End Function

Function GetCachedVolumes(conn)
    Dim cached : cached = CacheGet("Volumes_All")
    If Not IsEmpty(cached) Then
        GetCachedVolumes = cached
        Exit Function
    End If
    Dim rs, volumes
    On Error Resume Next
    Set rs = conn.Execute("SELECT VolumeID, VolumeName, VolumeML, PriceMultiplier FROM Volumes WHERE IsActive=1 ORDER BY VolumeML")
    If Err.Number = 0 And Not rs Is Nothing Then
        volumes = ""
        Do While Not rs.EOF
            volumes = volumes & rs("VolumeID") & "=" & rs("VolumeName") & "=" & rs("VolumeML") & "=" & rs("PriceMultiplier") & Chr(2)
            rs.MoveNext
        Loop
        rs.Close
        CacheSet "Volumes_All", volumes, 600
    End If
    Err.Clear : Set rs = Nothing
    On Error GoTo 0
    GetCachedVolumes = volumes
End Function
%>
<!--#include file="cdn_config.asp"-->