/**
 * PerfumeShop PWA Service Worker
 * V11.1 - 离线缓存支持
 */

const CACHE_NAME = 'perfumeshop-v11.1';
const OFFLINE_PAGE = '/offline.html';

// 需要缓存的核心资源
const STATIC_ASSETS = [
  '/',
  '/index.asp',
  '/products.asp',
  '/css/style.css',
  '/css/pages.css',
  '/css/buttons.css',
  '/css/responsive.css',
  '/css/design-tokens.css',
  '/js/main.js',
  '/images/logo.png',
  '/images/default-product.svg',
  'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css',
  'https://code.jquery.com/jquery-3.6.0.min.js'
];

// 安装事件：缓存核心资源
self.addEventListener('install', (event) => {
  console.log('[SW] Installing service worker...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[SW] Caching core assets...');
        return cache.addAll(STATIC_ASSETS).catch((err) => {
          console.error('[SW] Cache addAll failed:', err);
        });
      })
      .then(() => self.skipWaiting())
  );
});

// 激活事件：清理旧缓存
self.addEventListener('activate', (event) => {
  console.log('[SW] Activating service worker...');
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => {
            console.log('[SW] Deleting old cache:', name);
            return caches.delete(name);
          })
      );
    }).then(() => self.clients.claim())
  );
});

// 网络请求拦截
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);

  // 跳过非GET请求
  if (request.method !== 'GET') {
    return;
  }

  // 跳过ASP页面（需要实时数据）
  if (url.pathname.endsWith('.asp')) {
    return;
  }

  // 跳过外部资源（跨域）
  if (url.origin !== location.origin && !url.hostname.includes('cdnjs.cloudflare.com')) {
    return;
  }

  event.respondWith(
    // 优先使用缓存，失败则请求网络
    caches.match(request)
      .then((cachedResponse) => {
        if (cachedResponse) {
          console.log('[SW] Cache hit:', url.pathname);
          return cachedResponse;
        }

        console.log('[SW] Fetching from network:', url.pathname);
        return fetch(request)
          .then((response) => {
            // 只缓存成功的响应
            if (!response || response.status !== 200 || response.type !== 'basic') {
              return response;
            }

            // 克隆响应用于缓存
            const responseToCache = response.clone();
            caches.open(CACHE_NAME)
              .then((cache) => {
                cache.put(request, responseToCache);
              });

            return response;
          })
          .catch((error) => {
            console.error('[SW] Fetch failed:', error);
            
            // 返回离线页面
            if (request.headers.get('Accept').includes('text/html')) {
              return caches.match(OFFLINE_PAGE);
            }
            
            return new Response('Offline', { status: 503 });
          });
      })
  );
});

// 后台同步（可选）
self.addEventListener('sync', (event) => {
  if (event.tag === 'sync-cart') {
    console.log('[SW] Background sync triggered');
    // 这里可以同步购物车数据
  }
});

// 推送通知（可选）
self.addEventListener('push', (event) => {
  if (event.data) {
    const data = event.data.json();
    const options = {
      body: data.body,
      icon: '/images/icons/icon-192x192.png',
      badge: '/images/icons/icon-72x72.png',
      vibrate: [100, 50, 100],
      data: {
        dateOfArrival: Date.now(),
        primaryKey: 1
      },
      actions: [
        {
          action: 'explore',
          title: '查看详情',
          icon: '/images/icons/icon-72x72.png'
        },
        {
          action: 'close',
          title: '关闭',
          icon: '/images/icons/icon-72x72.png'
        }
      ]
    };
    event.waitUntil(
      self.registration.showNotification(data.title, options)
    );
  }
});

console.log('[SW] Service Worker loaded');
